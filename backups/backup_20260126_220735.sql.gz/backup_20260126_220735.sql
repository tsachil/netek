--
-- PostgreSQL database dump
--

\restrict iuqHKW7ifCls3qG5zcqh36qwbLwVFrpVqhipf75BRT9OKiBoNjJNkJgXpUYIm1E

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AccountType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AccountType" AS ENUM (
    'CHECKING',
    'SAVINGS'
);


ALTER TYPE public."AccountType" OWNER TO postgres;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Role" AS ENUM (
    'TELLER',
    'MANAGER',
    'ADMIN'
);


ALTER TYPE public."Role" OWNER TO postgres;

--
-- Name: TransactionType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TransactionType" AS ENUM (
    'DEPOSIT',
    'WITHDRAWAL',
    'TRANSFER'
);


ALTER TYPE public."TransactionType" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Account" (
    id text NOT NULL,
    "customerId" text NOT NULL,
    type public."AccountType" NOT NULL,
    balance numeric(65,30) DEFAULT 0.0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Account" OWNER TO postgres;

--
-- Name: Branch; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Branch" (
    id text NOT NULL,
    name text NOT NULL,
    code text NOT NULL
);


ALTER TABLE public."Branch" OWNER TO postgres;

--
-- Name: Customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Customer" (
    id text NOT NULL,
    name text NOT NULL,
    email text,
    phone text,
    "branchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Customer" OWNER TO postgres;

--
-- Name: Session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Session" (
    sid text NOT NULL,
    sess jsonb NOT NULL,
    expire timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Session" OWNER TO postgres;

--
-- Name: Transaction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Transaction" (
    id text NOT NULL,
    "accountId" text NOT NULL,
    amount numeric(65,30) NOT NULL,
    type public."TransactionType" NOT NULL,
    "performedBy" text NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Transaction" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id text NOT NULL,
    "googleId" text NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    role public."Role" DEFAULT 'TELLER'::public."Role" NOT NULL,
    "branchId" text NOT NULL
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Data for Name: Account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Account" (id, "customerId", type, balance, "createdAt") FROM stdin;
5e11b44b-1463-47e0-b984-fe41439e70c9	09ceda60-71cc-4ec0-a8a0-ad830c06965c	CHECKING	4279.000000000000000000000000000000	2026-01-26 19:53:23.557
c942f63e-bc51-4b74-a031-ae358eef7826	09ceda60-71cc-4ec0-a8a0-ad830c06965c	SAVINGS	22345.000000000000000000000000000000	2026-01-26 19:53:23.557
5507a20b-5f9f-4b6c-aaa7-e3e6ca4233d4	fe566b7f-237d-4800-866d-d5c584601007	CHECKING	2453.000000000000000000000000000000	2026-01-26 19:53:23.56
e9c901f7-486b-4f98-a015-a90c5af0300c	fe566b7f-237d-4800-866d-d5c584601007	SAVINGS	7231.000000000000000000000000000000	2026-01-26 19:53:23.56
bf4d82c1-5c3e-493a-a3cc-e038167fe4d0	a8851a8a-528a-4d46-aa83-1832aab40c56	CHECKING	5369.000000000000000000000000000000	2026-01-26 19:53:23.562
e9f17c09-baa6-4294-9da0-844b15695d11	a8851a8a-528a-4d46-aa83-1832aab40c56	SAVINGS	18706.000000000000000000000000000000	2026-01-26 19:53:23.562
0b2dbd47-4add-4401-accf-644cbbc31223	45a730f5-2828-4971-8f7f-e1298ad998a8	CHECKING	500.000000000000000000000000000000	2026-01-26 19:53:23.564
22e43e23-0c37-4be6-b5a6-c8c6a0ce6c7d	8e68e858-41e3-469f-a751-2322d3da5c33	CHECKING	6570.000000000000000000000000000000	2026-01-26 19:53:23.561
37cd586a-22ce-4ff8-9e13-797dd233bb16	8e68e858-41e3-469f-a751-2322d3da5c33	SAVINGS	8439.000000000000000000000000000000	2026-01-26 19:53:23.561
051e943a-f79e-4d86-97c1-cb9454cbcf0e	56eaaaf1-2e41-46cd-9176-b12691cbc32b	CHECKING	357.000000000000000000000000000000	2026-01-26 19:53:23.563
\.


--
-- Data for Name: Branch; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Branch" (id, name, code) FROM stdin;
58bdeab8-4e89-4283-90f4-92c88c037d42	Headquarters	DEFAULT
d0db402c-89a0-4549-9ab4-2d5f5e92762e	Westside Branch	WEST
\.


--
-- Data for Name: Customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Customer" (id, name, email, phone, "branchId", "createdAt") FROM stdin;
09ceda60-71cc-4ec0-a8a0-ad830c06965c	Alice Freeman	alice@example.com	555-0101	58bdeab8-4e89-4283-90f4-92c88c037d42	2026-01-26 19:53:23.557
fe566b7f-237d-4800-866d-d5c584601007	Bob Smith	bob@example.com	555-0102	58bdeab8-4e89-4283-90f4-92c88c037d42	2026-01-26 19:53:23.56
8e68e858-41e3-469f-a751-2322d3da5c33	Charlie Davis	charlie@example.com	555-0103	58bdeab8-4e89-4283-90f4-92c88c037d42	2026-01-26 19:53:23.561
a8851a8a-528a-4d46-aa83-1832aab40c56	Diana Prince	diana@example.com	555-0104	58bdeab8-4e89-4283-90f4-92c88c037d42	2026-01-26 19:53:23.562
56eaaaf1-2e41-46cd-9176-b12691cbc32b	Eve Rogue	eve@westside.com	555-0201	d0db402c-89a0-4549-9ab4-2d5f5e92762e	2026-01-26 19:53:23.563
45a730f5-2828-4971-8f7f-e1298ad998a8	Frank Castle	frank@westside.com	555-0202	d0db402c-89a0-4549-9ab4-2d5f5e92762e	2026-01-26 19:53:23.564
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Session" (sid, sess, expire) FROM stdin;
9a0elXQhE__KIoyqsbAg6jIteevSEA12	{"cookie": {"path": "/", "secure": true, "expires": "2026-02-25T20:04:26.156Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 2592000000}, "passport": {"user": "d16ee699-dbcb-4b2d-b993-0489313fdae9"}}	2026-02-25 20:05:55
\.


--
-- Data for Name: Transaction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Transaction" (id, "accountId", amount, type, "performedBy", "timestamp") FROM stdin;
5b918c58-6223-4c3b-94ab-689ad4122e97	5e11b44b-1463-47e0-b984-fe41439e70c9	1000.000000000000000000000000000000	DEPOSIT	27227fcc-58f8-4318-8e30-433d3c2b0a5a	2026-01-26 19:53:23.557
702cb189-9b8d-4fc8-a160-f7b29d328ed5	5507a20b-5f9f-4b6c-aaa7-e3e6ca4233d4	1000.000000000000000000000000000000	DEPOSIT	27227fcc-58f8-4318-8e30-433d3c2b0a5a	2026-01-26 19:53:23.56
07af4a0b-3993-4ba7-bd5f-9ac9a7af9cf8	22e43e23-0c37-4be6-b5a6-c8c6a0ce6c7d	1000.000000000000000000000000000000	DEPOSIT	27227fcc-58f8-4318-8e30-433d3c2b0a5a	2026-01-26 19:53:23.561
4f2f70c5-7443-45ba-85f4-675b952506a7	bf4d82c1-5c3e-493a-a3cc-e038167fe4d0	1000.000000000000000000000000000000	DEPOSIT	27227fcc-58f8-4318-8e30-433d3c2b0a5a	2026-01-26 19:53:23.562
7280feb0-0146-4a54-b45b-a2d84866fee3	22e43e23-0c37-4be6-b5a6-c8c6a0ce6c7d	800.000000000000000000000000000000	DEPOSIT	d16ee699-dbcb-4b2d-b993-0489313fdae9	2026-01-26 19:54:04.994
171ec7fa-bfe4-497d-9103-797167594df6	22e43e23-0c37-4be6-b5a6-c8c6a0ce6c7d	50.000000000000000000000000000000	WITHDRAWAL	d16ee699-dbcb-4b2d-b993-0489313fdae9	2026-01-26 19:54:15.212
ce0d8fa1-9be7-408e-8cd7-c70002a1de03	37cd586a-22ce-4ff8-9e13-797dd233bb16	99.000000000000000000000000000000	DEPOSIT	d16ee699-dbcb-4b2d-b993-0489313fdae9	2026-01-26 19:54:23.019
33368d4f-75f7-4858-8478-c091d354ae6d	051e943a-f79e-4d86-97c1-cb9454cbcf0e	77.000000000000000000000000000000	WITHDRAWAL	d16ee699-dbcb-4b2d-b993-0489313fdae9	2026-01-26 20:05:02.483
90e548bf-bf29-4e25-b3e2-c6035fe5550e	051e943a-f79e-4d86-97c1-cb9454cbcf0e	66.000000000000000000000000000000	WITHDRAWAL	d16ee699-dbcb-4b2d-b993-0489313fdae9	2026-01-26 20:05:14.033
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, "googleId", email, name, role, "branchId") FROM stdin;
27227fcc-58f8-4318-8e30-433d3c2b0a5a	system_admin	admin@bank.com	System Admin	MANAGER	58bdeab8-4e89-4283-90f4-92c88c037d42
d16ee699-dbcb-4b2d-b993-0489313fdae9	109227309705213852626	tsachil@gmail.com	Tsachi Lutaty	MANAGER	d0db402c-89a0-4549-9ab4-2d5f5e92762e
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
9f75b831-c092-4687-8404-9b5eb038ed19	cc9644c25a73f9d250c5d6196e0b9ee71973e384cfa9e23f27e7d8e06015463b	2026-01-26 19:40:35.994226+00	20260126181738_init	\N	\N	2026-01-26 19:40:35.97332+00	1
8569acb2-2830-41d6-a4c7-5ad420181b0e	082e62bd1f071dec5a245fefb7b863571df5812d91aeb6c61f5d2248a06c2c4f	2026-01-26 19:40:35.998733+00	20260126193817_add_session_table	\N	\N	2026-01-26 19:40:35.994995+00	1
\.


--
-- Name: Account Account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_pkey" PRIMARY KEY (id);


--
-- Name: Branch Branch_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Branch"
    ADD CONSTRAINT "Branch_pkey" PRIMARY KEY (id);


--
-- Name: Customer Customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Customer"
    ADD CONSTRAINT "Customer_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (sid);


--
-- Name: Transaction Transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Transaction"
    ADD CONSTRAINT "Transaction_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Branch_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Branch_code_key" ON public."Branch" USING btree (code);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_googleId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_googleId_key" ON public."User" USING btree ("googleId");


--
-- Name: Account Account_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Customer Customer_branchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Customer"
    ADD CONSTRAINT "Customer_branchId_fkey" FOREIGN KEY ("branchId") REFERENCES public."Branch"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Transaction Transaction_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Transaction"
    ADD CONSTRAINT "Transaction_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public."Account"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Transaction Transaction_performedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Transaction"
    ADD CONSTRAINT "Transaction_performedBy_fkey" FOREIGN KEY ("performedBy") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: User User_branchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_branchId_fkey" FOREIGN KEY ("branchId") REFERENCES public."Branch"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict iuqHKW7ifCls3qG5zcqh36qwbLwVFrpVqhipf75BRT9OKiBoNjJNkJgXpUYIm1E

